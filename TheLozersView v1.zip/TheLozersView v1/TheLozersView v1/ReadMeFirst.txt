Hey There!

My name is Jesse_the_lozer, and I wanted to give some basic information about this program before use,
or you could be reading this after using it, anyways the TheLozersView program will explain inside
but there is also an extra utility in the Extra Utilities Folder. This is important for two step
installations that will not allow TheLozersView to work properly. Just open it up and it'll explain 
all the steps you need. 

Thanks for Checking in, and make sure to follow the people in The lozers group 
Instagrams: 
@jesse_the_lozer
@btw.samuell
@plzdontclapmycheecks